package emailapp;

public class EmailApp {

	public static void main(String[] args) {
		Email eml = new Email("John","Smith");
		System.out.println(eml.showInfo());

	}

}
